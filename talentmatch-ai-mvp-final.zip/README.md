# TalentMatch AI MVP

Mobile-first recruitment marketplace prototype.

## Run
Node.js 20+:
npm install
npm run dev

Open http://localhost:3000

## Included
- Landing page
- Candidate profile and resume upload UI
- Employer job search
- Transparent demo matching results
- Employer monetization/pricing concept
- Responsive mobile design

## Production roadmap
Authentication, PostgreSQL, secure resume storage, PDF/DOCX parsing, AI extraction, hybrid matching, employer billing, messaging, consent/audit logs, deletion/export controls, security and regional privacy/employment-law review.

Demo matching data is not an automated hiring decision system.
